#!/bin/sh
# Clean tmp files and directories

rm *.log
rm -rf data/output
