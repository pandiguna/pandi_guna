# Save as multiplying.py

def double(x):
    return 2*x

def triple(x):
    return 3*x

def quadruple(x):
    return 4*x
